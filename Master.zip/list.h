#ifndef list_h
#define list_h

#include <stdio.h>

typedef struct element_{
    char ip[20], surname[20], name[20];
    int port;
    struct element_ * next;
}element;

element * add_element(char name[20], char surname[20],char ip[20], element * ptr_to_first);

void print_list(element * ptr_to_first);

void freeList(element * ptr_to_first);

element * deleteElement(element * ptr_to_first, char name[20], char surname[20]);

#endif /* list_h */
