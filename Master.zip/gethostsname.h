#ifndef gethostsname_h
#define gethostsname_h

#include "gethostsname.h"

struct in_addr getaddressbyname(char** name);

struct in_addr get_host_name();

#endif /* gethostsname_h */
